for i in range(1,10):
   print(i)
